Package Uninstaller v1.3
(c) 2018 Movinarc

// ABOUT ======================================

This plugin helps you remove and cleanup any assets you have imported, from your project. You no longer need to remove files one by one.


// USAGE ======================================

- Goto "Assets/Uninstall Package..."
- Select from the list of the assets you have already imported from Asset Store or open the package you want to remove from your hard disk. 
- Click "Uninstall" to open the file selector window.
- Choose the contents you want to keep or remove.


// LINKS ======================================

Forum Thread: https://forum.unity.com/threads/unity-package-uninstaller.378829