﻿#if UNITY_EDITOR

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Assertions;
using AssetsPathExtUtils;
using System.IO;
using System;
using UnityEditor;

public class WebGLAudioConverter
{
	public enum AudioFormat
	{
		OGG,
		MP3,
		AAC
	}

	// ---------------------------------------------------------------------------------------------------
	public static string DeliverToTempSoundEditor(string filepath, bool alreadyExisted)
	{
		Assert.IsTrue(File.Exists(filepath), filepath + " doesn't exists");
		Assert.IsTrue(filepath.IsRelativeTemp() || filepath.IsRelativeStreamingAssets(), filepath + " is not relative");

		var tempDirRelative = CreateTempEditorSoundsDirectoryRelative();
		return Deliver(filepath, Path.Combine(tempDirRelative, Path.GetFileName(filepath)), alreadyExisted);
	}

	// ---------------------------------------------------------------------------------------------------
	public static string DeliverToStreamingAssets(string filepath)
	{
		Assert.IsTrue(File.Exists(filepath), filepath + " doesn't exists");
		Assert.IsTrue(filepath.IsRelativeTemp() || filepath.IsRelativeStreamingAssets(), filepath + " is not relative");

		return Deliver(filepath, Path.Combine("Assets/StreamingAssets/", Path.GetFileName(filepath)), false);
	}

	// ---------------------------------------------------------------------------------------------------
	public static string ConvertAudio(string audioRelativeFilePath, out bool alreadyExisted, AudioFormat format)
	{
		Assert.IsTrue(audioRelativeFilePath.IsRelativeTemp() || audioRelativeFilePath.IsRelativeStreamingAssets(), audioRelativeFilePath + " is not relative audioRelativeFilePath");

		var newFilename = audioRelativeFilePath.FileNameWithExt(ExtByAudioFormat(format));

		Assert.IsTrue(newFilename.IsRelativeTemp() || newFilename.IsRelativeStreamingAssets(), newFilename + " is not relative newFilename");

		alreadyExisted = File.Exists(newFilename);

		if (File.Exists(audioRelativeFilePath) == false)
		{
			Debug.LogErrorFormat("{0} doesn't exist. cannot convert", audioRelativeFilePath);
			return null;
		}

		if (alreadyExisted == false)
		{
			string title = (format == AudioFormat.OGG) ? "Converting audio for Editor use" : "Converting audio for WebGL";

			string detailedMessage = string.Format("Please wait, {0} -> {1} is generating...", audioRelativeFilePath, newFilename);
			string successMessage = string.Format("{1} generation completed successfully!", audioRelativeFilePath, newFilename);
			string shortMessage = string.Format("{1} is generating...", audioRelativeFilePath, newFilename);
			Debug.Log(detailedMessage);

			EditorUtility.DisplayProgressBar(title, shortMessage, 0.1f);

			string execFilename;
			string fmt = CommandByAudioFormat(format, out execFilename);

            var sourceFileName = audioRelativeFilePath.RelativeToAbsoluteUri().LocalPath;
            var destFileName = newFilename.RelativeToAbsoluteUri().LocalPath;

            var command = string.Format(fmt, sourceFileName, destFileName);

			try
			{
				var psi = new System.Diagnostics.ProcessStartInfo(); 
				psi.FileName = execFilename;
				psi.UseShellExecute = false; 
				psi.WindowStyle = System.Diagnostics.ProcessWindowStyle.Minimized;
				psi.CreateNoWindow = true; 
				psi.RedirectStandardOutput = true;
				psi.Arguments = command;

				var p = System.Diagnostics.Process.Start(psi);
				p.WaitForExit();

				if (p.ExitCode != 0)
					Debug.LogErrorFormat("[{2} {0}] returns {1}", psi.Arguments, p.ExitCode, psi.FileName);
				else
					Debug.Log(successMessage);
			}
			catch (Exception ex)
			{
				Debug.LogErrorFormat("An error occurred trying to run \"{0}\":" + "\n" + ex.Message, execFilename);
				return null;
			}
			finally
			{
				EditorUtility.ClearProgressBar();
			}
		}

		if (File.Exists(newFilename))
			return newFilename;
		return null;
	}

	// ---------------------------------------------------------------------------------------------------
	public static void GenerateEditorSoundIfMissing(string webGLSoundRelativePath)
	{
        if (string.IsNullOrEmpty(webGLSoundRelativePath))
            return;

		if (webGLSoundRelativePath.IsRelativeTemp() == false && webGLSoundRelativePath.IsRelativeStreamingAssets() == false)
			return; // probably external source

		if (File.Exists(webGLSoundRelativePath) == false)
			Debug.LogError("WebGL Sound (mp3/aac) must exist, to generate Editor sound (ogg). But [" + webGLSoundRelativePath + "] doesn't");

		var editorFormat = AudioFormat.OGG;

		var editorFilename = EditorSoundRelativeFilename(webGLSoundRelativePath, editorFormat);
		if (File.Exists(editorFilename))
			return; 

		var alreadyExisted = false;
		var oggPath = ConvertAudio(webGLSoundRelativePath, out alreadyExisted, editorFormat);
		if (oggPath != null)
			DeliverToTempSoundEditor(oggPath, alreadyExisted);
		else
			Debug.LogErrorFormat("Failed to convert {0} to ogg", webGLSoundRelativePath);
	}

	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------


	static string ExtByAudioFormat(AudioFormat format)
	{
		switch (format)
		{
		case AudioFormat.OGG: return ".ogg";
		case AudioFormat.AAC: return ".m4a";
		case AudioFormat.MP3: return ".mp3";
		default:  throw new NotImplementedException("ExtByAudioFormat is not implemented for " + format);
		}
	}

	static string CommandByAudioFormat(AudioFormat format, out string filename)
	{
		return CommandByAudioFormatFSBTool(format, out filename);
		//return CommandByAudioFormatFFMPEG(format, out filename);
	}
	static string CommandByAudioFormatFSBTool(AudioFormat format, out string filename)
	{
		string kFSBToolPath = "";
#if UNITY_EDITOR_WIN
kFSBToolPath = "Tools/FSBTool/FSBTool.exe";
#else
		kFSBToolPath = "Tools/FSBTool/FSBTool";
#endif

		filename = (Path.Combine(EditorApplication.applicationContentsPath, kFSBToolPath));

		if (File.Exists(filename) == false)
			Debug.LogError(filename + " filename doesn't exist");

		if (kFSBToolPath == "")
			return "";

		string lib = Path.GetDirectoryName(filename);			
		string tempFolder = "Temp".RelativeToAbsoluteUri().LocalPath;
		switch (format)
		{
		case AudioFormat.OGG: return "-i \"{0}\" -o \"{1}\" -l \"" + lib + "\" -h \"" + tempFolder + "\" -c vorbis -C ogg";
		case AudioFormat.MP3: return "-i \"{0}\" -o \"{1}\" -l \"" + lib + "\" -h \"" + tempFolder + "\" -c mp3 -C mpeg";
		default:  throw new NotImplementedException("CommandByAudioFormat is not implemented for " + format);
		}
	}

	static string CommandByAudioFormatFFMPEG(AudioFormat format, out string filename)
	{
		filename = "/usr/local/bin/ffmpeg";
		switch (format)
		{
		case AudioFormat.OGG: return "-i \"{0}\" -vn -c:a libvorbis -qscale:a 5 \"{1}\"";
		case AudioFormat.AAC: return "-i \"{0}\" -vn -c:a aac -qscale:a 5 \"{1}\"";
		default:  throw new NotImplementedException("CommandByAudioFormat is not implemented for " + format);
		}
	}

	static string CreateTempEditorSoundsDirectoryRelative()
	{
		var tempDir = "Temp/EditorSounds";

		if (Directory.Exists(tempDir) == false)
		{
			Directory.CreateDirectory(tempDir);
			Debug.Log(tempDir + " created");
		}

		return tempDir;
	}

	static string Deliver(string src, string dest, bool copy)
	{
		if (src == dest)
			return src;

		Debug.LogFormat("[{0}] {2} to [{1}]", src, dest, copy ? "copying" : "moving");

		Assert.IsTrue(File.Exists(src), src + " doesn't exists");

		if (File.Exists(dest))
		{
			Debug.LogFormat("[{0}] deleting...", dest);
			try
			{
				File.Delete(dest);
			}
			catch (Exception e)
			{
				Debug.LogFormat("[{0}] delete failed {1}", dest, e.ToString());
			}
		}

		if (copy)
			File.Copy(src, dest, true);
		else
			File.Move(src, dest);

		Debug.LogFormat("[{0}] {2} to [{1}]", src, dest, copy ? "copied" : "moved");

		Assert.IsTrue(File.Exists(dest));

		return dest;
	}

	static string EditorSoundRelativeFilename(string webGLSound, AudioFormat editorFormat)
	{
		var editorSoundsDirRelative = CreateTempEditorSoundsDirectoryRelative();
		var editorFileName = Path.GetFileNameWithoutExtension(webGLSound) + ExtByAudioFormat(editorFormat);
		return Path.Combine(editorSoundsDirRelative, editorFileName);
	}
}

#endif