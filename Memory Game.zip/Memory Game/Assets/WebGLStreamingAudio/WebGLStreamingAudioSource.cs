﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Assertions;
using AssetsPathExtUtils;

public class WebGLStreamingAudioSource : MonoBehaviour
{
	WebGLStreamingAudioSourceInterop interop;

	[SerializeField]
	bool m_playOnAwake = false;

	[SerializeField]
	bool m_3D = true;


	[SerializeField]
	string m_clipWebGLRelativeUrl = string.Empty;

	#if UNITY_EDITOR
	[SerializeField]
	string m_clipEditorRelativeUrl = string.Empty;
	#endif

	public string clipURL
	{
		get {
			#if UNITY_WEBGL && !UNITY_EDITOR 
			string relativeURL = m_clipWebGLRelativeUrl;
			#else
			string relativeURL = m_clipEditorRelativeUrl;
			#endif

			if (relativeURL.IsRelativeTemp() || relativeURL.IsRelativeStreamingAssets())
			{
				return relativeURL.RelativeToAbsoluteUri().AbsoluteUri;
			}

			return relativeURL;
		}
		set {
			m_clipWebGLRelativeUrl = value;

			#if UNITY_EDITOR
			if (string.IsNullOrEmpty(this.m_clipWebGLRelativeUrl) ^ string.IsNullOrEmpty(this.m_clipEditorRelativeUrl))
				Debug.LogError("Probably you forgot to specify URL", this);

			WebGLAudioConverter.GenerateEditorSoundIfMissing(this.m_clipWebGLRelativeUrl);
			#endif

			interop = new WebGLStreamingAudioSourceInterop(this.clipURL, this.gameObject);
			interop.invalidated += (sender) => {
				Assert.IsTrue(sender == interop);
				interop = null;
			};
			if (this.m_3D && interop != null)
				interop.SetPosition3d(this.transform.position);
		}
	}

	public float Volume
	{
		get {
			if (interop == null) 
				return 0.0f; 
			return interop.Volume; 
		}
		set { interop.Volume = value; }
	}

	public float CurrentTime
	{
		get { 
			if (interop == null) 
				return 0.0f; 
			return interop.CurrentTime; 
		}
		set { interop.CurrentTime = value; }
	}

	public float Duration
	{
		get {
			if (interop == null)
				return 0.0f;
			return interop.Duration;
		}
	}

	public bool IsPlaying
	{
		get {
			if (interop == null) 
				return false;
			return interop.IsPlaying;
		}
	}

	public void Play()
	{
		if (interop != null)
			interop.Play();
	}

	public void Pause()
	{
		if (interop != null)
			interop.Pause();
	}

	void OnEnable()
	{
        if (string.IsNullOrEmpty(m_clipWebGLRelativeUrl))
            return;

        this.clipURL = m_clipWebGLRelativeUrl;
		if (this.m_playOnAwake)
			Play();
	}

	void OnDisable()
	{
		Pause();
	}

	void LateUpdate()
	{
		if (interop != null && this.m_3D && this.IsPlaying)
			interop.SetPosition3d(this.transform.position);
	}
}
