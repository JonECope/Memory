﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Assertions;
using UnityEditor;
using System.IO;
using System;
using AssetsPathExtUtils;

[CustomEditor(typeof(WebGLStreamingAudioSource))]
[CanEditMultipleObjects]
public class WebGLStreamingAudioSourceEditor : Editor
{
	SerializedProperty m_clipWebGLRelativeUrl;
	SerializedProperty m_clipEditorRelativeUrl;

	void OnEnable()
    {
		m_clipWebGLRelativeUrl = serializedObject.FindProperty("m_clipWebGLRelativeUrl");
		m_clipEditorRelativeUrl = serializedObject.FindProperty("m_clipEditorRelativeUrl");
	}

	public override void OnInspectorGUI ()
    {
		serializedObject.Update();
        DrawDefaultInspector ();
        EditorGUILayout.Space ();
        DropAreaGUI ();		

		EditorGUILayout.HelpBox("Clip URL - Drag'n'Drop audio clip from StreamingAsset folder or type remote URL manually", MessageType.Info);
		EditorGUILayout.HelpBox(".MP3 is currently supported by almost all browsers", MessageType.Info);
		EditorGUILayout.HelpBox(".OGG is used for playing back in Editor", MessageType.Info);
		serializedObject.ApplyModifiedProperties();
    }

	public void DropAreaGUI ()
    {
        Event evt = Event.current;
        
		switch (evt.type)
		{
        case EventType.DragUpdated:
		case EventType.DragPerform:
        	DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
         
            if (evt.type == EventType.DragPerform)
			{
				var refs = DragAndDrop.objectReferences;
				if (refs.Length >= 1)
				{
					DragAndDrop.AcceptDrag ();
					OnDragAudioClip(refs[0]);
				}
            }
            break;
        }
    }

    void ConvertResources(string path)
	{
		var ext = Path.GetExtension(path); 

		var isWebGLSound	= ext == ".mp3";
		var isEditorSound	= ext == ".ogg"; 

		string webGLResourcePath	= isWebGLSound 	? path : string.Empty;
		string editorResourcePath	= isEditorSound ? path : string.Empty;

		// create OGG for Editor if we don't have the one
		if (string.IsNullOrEmpty(editorResourcePath))
		{
			var alreadyExisted = false;
			var oggPath = WebGLAudioConverter.ConvertAudio(path, out alreadyExisted, WebGLAudioConverter.AudioFormat.OGG);
			if (oggPath != null)
				editorResourcePath = WebGLAudioConverter.DeliverToTempSoundEditor(oggPath, alreadyExisted);
		}

		// crete MP3 for WebGL if we don't have the one
		if (string.IsNullOrEmpty(webGLResourcePath))
		{
			var alreadyExisted = false;
			var mp3Path = WebGLAudioConverter.ConvertAudio(path, out alreadyExisted, WebGLAudioConverter.AudioFormat.MP3);
			if (mp3Path != null)
				webGLResourcePath = WebGLAudioConverter.DeliverToStreamingAssets(mp3Path);
		}

		if (string.IsNullOrEmpty(webGLResourcePath) || string.IsNullOrEmpty(editorResourcePath))
		{
			webGLResourcePath = editorResourcePath = string.Empty;
			Debug.LogError("Cannot convert audio files");
		}
		else
		{
			bool initialFileIsNotUsed = isWebGLSound == false && isEditorSound == false;
			if (initialFileIsNotUsed)
				Debug.LogWarningFormat("We're using .mp3 in WebGL and .ogg in the editor. [{1}] will be used instead of [{0}]. Maybe you should delete {2} file from StreamingAssets to save build size",
					path, webGLResourcePath, ext);
			AssetDatabase.Refresh();
		}

		m_clipWebGLRelativeUrl.stringValue = webGLResourcePath;
		m_clipEditorRelativeUrl.stringValue = editorResourcePath;
	}

	List<string> possibleToConvert = new List<string> {".mp3", ".ogg", ".wav", ".aac", ".aif"};

	void OnDragAudioClip(UnityEngine.Object clip)
	{
		string path = AssetDatabase.GetAssetPath(clip);

		if (string.IsNullOrEmpty(path))
			return;

		if (path.IsRelativeStreamingAssets() == false && path.IsRelativeTemp() == false)
		{
			Debug.LogErrorFormat("[WebGLStreamingAudioSource] <{0}> cannot be used, since it's not in StreamingAssets folder", path);
			return;
		}

		var ext = Path.GetExtension(path); 
			
		if (possibleToConvert.Contains(ext))
			ConvertResources(path);
		else
			Debug.LogErrorFormat("[WebGLStreamingAudioSource] <{0}> extention is not supported neither by editor nor by webgl player. Or editor cannot convert this - only {1} are convertible", 
				ext, string.Join(", ", possibleToConvert.ToArray()));
	}
}
